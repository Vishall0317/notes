package com.infy.ekart.customer.dto;

public enum OrderStatus {
	 PLACED, CONFIRMED, CANCELLED
}
