package com.infy.ekart.customer.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.infy.ekart.customer.entity.Order;

@Repository(value = "orderRepository")
public interface OrderRepository extends CrudRepository<Order, Integer> {

	List<Order> findByCustomerEmailId(String customerEmailId);
}
