package com.infy.ekart.customer.api;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infy.ekart.customer.dto.CartProductDTO;
import com.infy.ekart.customer.dto.CustomerCartDTO;
import com.infy.ekart.customer.dto.CustomerDTO;
import com.infy.ekart.customer.dto.ProductDTO;
import com.infy.ekart.customer.exception.EKartCustomerException;
import com.infy.ekart.customer.service.CustomerService;

@CrossOrigin
@RestController
@Validated
@RequestMapping(value = "/customer-api")
public class CustomerAPI {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private RestTemplate template;

	@Autowired
	private Environment environment;

	static Log logger = LogFactory.getLog(CustomerAPI.class);

	@PostMapping(value = "/login")
	public ResponseEntity<CustomerDTO> authenticateCustomer(@Valid @RequestBody CustomerDTO customerDTO)
			throws EKartCustomerException {
		logger.info("CUSTOMER TRYING TO LOGIN, VALIDATING CREDENTIALS. CUSTOMER EMAIL ID: " + customerDTO.getEmailId());
		CustomerDTO customerDTOFromDB = customerService.authenticateCustomer(customerDTO.getEmailId(),
				customerDTO.getPassword());
		logger.info("CUSTOMER LOGIN SUCCESS, CUSTOMER EMAIL : " + customerDTOFromDB.getEmailId());
		return new ResponseEntity<>(customerDTOFromDB, HttpStatus.OK);
	}

	@PostMapping(value = "/register")
	public ResponseEntity<String> registerCustomer(@Valid @RequestBody CustomerDTO customerDTO)
			throws EKartCustomerException {
		logger.info("CUSTOMER TRYING TO REGISTER. CUSTOMER EMAIL ID: " + customerDTO.getEmailId());
		return new ResponseEntity<>(environment.getProperty("CustomerAPI.CUSTOMER_REGISTRATION_SUCCESS")
				+ customerService.registerNewCustomer(customerDTO), HttpStatus.OK);
	}

	@PutMapping(value = "/customer/{customerEmailId}/address")
	public ResponseEntity<String> updateShippingAddress(
			@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+", message = "{invalid.email.format}") @PathVariable("customerEmailId") String customerEmailId,
			@RequestBody String address) throws EKartCustomerException {
		customerService.updateShippingAddress(customerEmailId, address);
		return new ResponseEntity<>(environment.getProperty("CustomerAPI.UPDATE_ADDRESS_SUCCESS"), HttpStatus.OK);
	}

	@DeleteMapping(value = "/customer/{customerEmailId}")
	public ResponseEntity<String> deleteShippingAddress(
			@Pattern(regexp = "[a-zA-Z0-9._]+@[a-zA-Z]{2,}\\.[a-zA-Z][a-zA-Z.]+", message = "{invalid.email.format}") @PathVariable("customerEmailId") String customerEmailId)
			throws EKartCustomerException {
		customerService.deleteShippingAddress(customerEmailId);
		return new ResponseEntity<>(environment.getProperty("CustomerAPI.CUSTOMER_ADDRESS_DELETED_SUCCESS"), HttpStatus.OK);
	}

	@PostMapping(value = "/customercarts/add-product")
	public ResponseEntity<String> addProductToCart(@Valid @RequestBody CustomerCartDTO customerCartDTO)
			throws EKartCustomerException {
		customerService.getCustomerByEmailId(customerCartDTO.getCustomerEmailId());
		for (CartProductDTO cartProductDTO : customerCartDTO.getCartProducts()) {
			template.getForEntity("http://ProductMS/Ekart/product-api/product/" + cartProductDTO.getProduct().getProductId(), ProductDTO.class);
		}
		return template.postForEntity("http://CustomerCartMS/Ekart/customercart-api/products", customerCartDTO, String.class);
	}
}
