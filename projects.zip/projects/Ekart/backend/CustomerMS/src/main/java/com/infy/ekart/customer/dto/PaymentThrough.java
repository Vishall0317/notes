package com.infy.ekart.customer.dto;

public enum PaymentThrough {

	DEBIT_CARD, CREDIT_CARD
}
