package com.infy.ekart.payment.dto;

public enum TransactionStatus {
TRANSACTION_SUCCESS , TRANSACTION_FAILED
}
