package com.infy.ekart.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.ekart.product.dto.ProductDTO;
import com.infy.ekart.product.entity.Product;
import com.infy.ekart.product.exception.EKartProductException;
import com.infy.ekart.product.repository.ProductRepository;

@Service(value = "customerProductService")
@Transactional
public class CustomerProductServiceImpl implements CustomerProductService {
	@Autowired
	private ProductRepository productRepository;

	@Override
	public List<ProductDTO> getAllProducts() throws EKartProductException {
		Iterable<Product> products = productRepository.findAll();
		List<ProductDTO> dtoProducts = new ArrayList<>();
		products.forEach(product -> {
			ProductDTO productDTO = new ProductDTO();
			productDTO.setProductId(product.getProductId());
			productDTO.setName(product.getName());
			productDTO.setBrand(product.getBrand());
			productDTO.setCategory(product.getCategory());
			productDTO.setAvailableQuantity(product.getAvailableQuantity());
			productDTO.setDescription(product.getDescription());
			productDTO.setPrice(product.getPrice());
			dtoProducts.add(productDTO);
		});
		if(dtoProducts.isEmpty()) {
			throw new EKartProductException("General.EXCEPTION_MESSAGE");
		}
		return dtoProducts;
	}

	@Override
	public ProductDTO getProductById(Integer productId) throws EKartProductException {
		Optional<Product> optional = productRepository.findById(productId);
        Product product = optional.orElseThrow(() ->
                new EKartProductException("ProductService.PRODUCT_NOT_AVAILABLE"));
        ProductDTO productDTO = new ProductDTO();
        productDTO.setProductId(product.getProductId());
        productDTO.setName(product.getName());
        productDTO.setBrand(product.getBrand());
        productDTO.setCategory(product.getCategory());
        productDTO.setAvailableQuantity(product.getAvailableQuantity());
        productDTO.setDescription(product.getDescription());
        productDTO.setPrice(product.getPrice());
        return productDTO;
	}

	@Override
	public void reduceAvailableQuantity(Integer productId, Integer quantity) throws EKartProductException {
		Optional<Product> optional = productRepository.findById(productId);
        Product product = optional.orElseThrow(() ->
                new EKartProductException("ProductService.PRODUCT_NOT_AVAILABLE"));
        product.setAvailableQuantity(product.getAvailableQuantity() - quantity);
	}
}
