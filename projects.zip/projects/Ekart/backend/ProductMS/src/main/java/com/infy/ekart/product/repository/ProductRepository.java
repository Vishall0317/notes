package com.infy.ekart.product.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.infy.ekart.product.entity.Product;

@Repository(value = "productRepository")
public interface ProductRepository extends CrudRepository<Product, Integer>{

	Optional<Product> findByProductId(Integer productId);
}
