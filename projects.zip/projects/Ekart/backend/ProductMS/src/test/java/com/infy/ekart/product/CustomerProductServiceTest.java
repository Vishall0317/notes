package com.infy.ekart.product;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import org.springframework.boot.test.context.SpringBootTest;

import com.infy.ekart.product.dto.ProductDTO;
import com.infy.ekart.product.entity.Product;
import com.infy.ekart.product.exception.EKartProductException;
import com.infy.ekart.product.repository.ProductRepository;
import com.infy.ekart.product.service.CustomerProductService;
import com.infy.ekart.product.service.CustomerProductServiceImpl;

@SpringBootTest
class CustomerProductServiceTest {

	@Mock
	private ProductRepository productRepository;

	@InjectMocks
	private CustomerProductService customerProductService = new CustomerProductServiceImpl();

	@Test
	void getAllProductsTestValidProducts() throws EKartProductException {
		Mockito.when(productRepository.findAll()).thenReturn(getProductDetailsList());
		List<ProductDTO> actualProducts = customerProductService.getAllProducts();
		Assertions.assertNotNull(actualProducts);
	}

	@Test
	void getAllProductsTestInValidProducts() throws EKartProductException {
		Mockito.when(productRepository.findAll()).thenReturn(Collections.emptyList());
		EKartProductException exception1 = Assertions.assertThrows(EKartProductException.class,
				() -> customerProductService.getAllProducts());
		Assertions.assertEquals("General.EXCEPTION_MESSAGE", exception1.getMessage());
	}

	@Test
	void getProductByIdTestValid() throws EKartProductException {
		Mockito.when(productRepository.findById(1000)).thenReturn(Optional.of(getProductDetails()));
		ProductDTO res = customerProductService.getProductById(getProductDtoDetails().getProductId());
		Assertions.assertNotNull(res);
	}

	@Test
	void getProductByIdTestInValid() throws EKartProductException {
		Mockito.when(productRepository.findById(1)).thenReturn(Optional.empty());
		EKartProductException exception1 = Assertions.assertThrows(EKartProductException.class,
				() -> customerProductService.getProductById(1));
		Assertions.assertEquals("ProductService.PRODUCT_NOT_AVAILABLE", exception1.getMessage());
	}

	@Test
	void reduceAvailableQuantityTestValid() throws EKartProductException {
		Mockito.when(productRepository.findById(1000)).thenReturn(Optional.of(getProductDetails()));
		customerProductService.reduceAvailableQuantity(1000, 5);
		Assertions.assertEquals(10, getProductDetails().getAvailableQuantity());

	}

	private Product getProductDetails() {
		Product product = new Product();
		product.setProductId(1000);
		product.setName("Bot E5s Plus");
		product.setBrand("Motobot");
		product.setCategory("Electronics - Mobile");
		product.setAvailableQuantity(10);
		product.setDescription(
				"Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product.setPrice(16000.0);
		return product;
	}

	private ProductDTO getProductDtoDetails() {
		ProductDTO productDTO = new ProductDTO();
		productDTO.setProductId(1000);
		productDTO.setName("Bot E5s Plus");
		productDTO.setBrand("Motobot");
		productDTO.setCategory("Electronics - Mobile");
		productDTO.setAvailableQuantity(10);
		productDTO.setDescription(
				"Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO.setPrice(16000.0);
		return productDTO;
	}

	private List<Product> getProductDetailsList() {
		List<Product> productIterable = new ArrayList<Product>();
		Product product1 = new Product();
		Product product2 = new Product();

		product1.setProductId(1000);
		product1.setName("Bot E5s Plus");
		product1.setBrand("Motobot");
		product1.setCategory("Electronics - Mobile");
		product1.setAvailableQuantity(150);
		product1.setDescription(
				"Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product1.setPrice(16000.0);

		product2.setProductId(1001);
		product2.setName("Xpress");
		product2.setBrand("Motobot");
		product2.setCategory("Electronics - Mobile");
		product2.setAvailableQuantity(150);
		product2.setDescription(
				"Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		product2.setPrice(16000.0);

		productIterable.add(product1);
		productIterable.add(product2);
		return productIterable;
	}

	private List<ProductDTO> getProductDtoDetailsList() {
		List<ProductDTO> expectedProducts = new ArrayList<>();
		ProductDTO productDTO1 = new ProductDTO();
		ProductDTO productDTO2 = new ProductDTO();

		productDTO1.setProductId(1000);
		productDTO1.setName("Bot E5s Plus");
		productDTO1.setBrand("Motobot");
		productDTO1.setCategory("Electronics - Mobile");
		productDTO1.setAvailableQuantity(150);
		productDTO1.setDescription(
				"Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO1.setPrice(16000.0);

		productDTO2.setProductId(1001);
		productDTO2.setName("Xpress");
		productDTO2.setBrand("Motobot");
		productDTO2.setCategory("Electronics - Mobile");
		productDTO2.setAvailableQuantity(150);
		productDTO2.setDescription(
				"Smart phone with (13+13)MP rear camera and 8MP front camera, 4GB RAM and 64GB ROM,5.5 inch FHD display, Snapdrag 625 processor");
		productDTO2.setPrice(16000.0);

		expectedProducts.add(productDTO1);
		expectedProducts.add(productDTO2);
		return expectedProducts;
	}
}