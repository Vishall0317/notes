import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Card } from 'src/app/model/card';
import { LoginValidators } from 'src/app/validators/login.validator';
import { AddCardService } from './add-card.service';

@Component({
  selector: 'app-add-card',
  templateUrl: './add-card.component.html',
  styleUrls: ['./add-card.component.css']
})
export class AddCardComponent implements OnInit {
  addNewCardForm!: FormGroup;
  successMessage!: string;
  errorMessage!: string;
  card!: Card;

  constructor(private formBuilder: FormBuilder, private addCardService: AddCardService) { }

  ngOnInit(): void {
    this.addNewCardForm = this.formBuilder.group({
      cardType: ['', [Validators.required, Validators.pattern('(DEBIT_CARD|CREDIT_CARD)')]],
      cardNumber: ['', [Validators.required, Validators.pattern('^[0-9]{16}$')]],
      cvv: ['', [Validators.required, Validators.pattern('^[0-9]{3}$')]],
      expiryDate: ['', [Validators.required, LoginValidators.validateExpiryDate]],
      nameOnCard: ['', [Validators.required, Validators.pattern('^[a-zA-Z][a-zA-Z ]{0,49}$')]],
    });
  }

  addNewCard() {
    this.errorMessage = '';
    this.successMessage = '';
    this.card = this.addNewCardForm.value as Card;
    console.log(this.card);
    this.addCardService.addNewCard(this.card).subscribe(
      (message) => {
        this.successMessage = message;
        this.addNewCardForm.reset();
      },
      (error) => (this.errorMessage = <any>error)
    );
  }
}
