import { Product } from "./product";

export class CartProduct {
    product!: Product;
    quantity!: number;
}