export class Customer {
  emailId!: string;
  name!: string;
  password!: string;
  phoneNumber!: string;
  address!: string;
}