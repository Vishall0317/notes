import { Component } from '@angular/core';

@Component({
  selector: 'app-authorisation-error',
  templateUrl: './authorisation-error.component.html',
})
export class AuthorisationErrorComponent {

  constructor() { }

}
